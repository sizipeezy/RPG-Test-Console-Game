﻿namespace Elfshock
{
    public interface IEngine
    {
        void Start();

    }
}
