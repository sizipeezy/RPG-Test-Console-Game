﻿namespace Elfshock.Contracts
{
    public interface IGameService
    {
        int CharacterSelect();

    }
}
