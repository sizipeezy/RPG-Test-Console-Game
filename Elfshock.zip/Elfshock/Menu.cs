﻿namespace Elfshock
{
    public enum Menu
    {
        MainMenu = 0,
        CharacterSelect = 1,
        InGame = 2,
        Exit = 3
    }
}
